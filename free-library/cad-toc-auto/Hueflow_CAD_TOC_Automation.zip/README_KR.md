# CAD 도면 리스트 반자동 생성 리습

AutoCAD에서 반복되는 시트폼 블록을 기준으로 도면 리스트를 자동 생성하는 AutoLISP입니다.

기존 도면을 전부 속성 블록으로 바꾸지 않아도, 이미 작성된 도면의 시트폼 안에 있는 일반 텍스트를 읽어 `SHEET / DWG NO / TITLE / SCALE` 목록을 생성합니다.

## 핵심 기능

- 반복되는 시트폼 블록을 기준으로 값 칸 위치를 학습
- 같은 폼 블록 전체를 자동 스캔
- 시트번호, 도면번호, 도면명, 축척을 표로 생성
- AutoCAD Table 또는 기존 목차선 위 TEXT 출력 지원
- `L-000` 같은 예외 항목은 수동 추가 가능

## 리습 파일

`cad_toc_auto.lsp`

## 로드 방법

AutoCAD 명령창에서:

```lisp
(load "C:/Users/kimyj/cad_toc_auto.lsp")
```

또는 `APPLOAD`로 `cad_toc_auto.lsp`를 로드합니다.

## 기본 사용 순서

### 1. 폼 기준 설정

명령어:

```text
TOCFORMSET
```

순서:

```text
1. 반복되는 시트폼 블록 하나 선택
2. SHEET NO 값 칸을 박스로 지정
3. DWG NO 값 칸을 박스로 지정
4. TITLE 값 칸을 박스로 지정
5. SCALE 값 칸을 박스로 지정
```

주의: 2~5번은 폼 전체가 아니라 값이 들어가는 칸만 작게 지정합니다.

### 2. 리스트 생성

명령어:

```text
TOCFORMSCAN
```

추천 선택:

```text
Create output? → Yes
Output mode → Table
Table insertion point → 빈 곳 클릭
```

## 보조 명령

```text
TOCSEMI
```

선택한 도면 제목란/텍스트 영역을 반자동 인식합니다.

```text
TOCSEMIALL
```

DWG 전체를 스캔하되, 기존 목차 영역을 제외하고 반자동 인식합니다.

```text
TOCCFG
```

도면번호 패턴, 축척 패턴, 출력 기본값 등을 설정합니다.

## 적합한 도면 조건

- 같은 이름의 시트폼 블록을 여러 도면에 반복 사용
- 도면번호, 도면명, 축척이 폼 안의 일정한 칸에 위치
- 값이 일반 TEXT/MTEXT여도 가능
- 폼이 스케일되어도 상대 위치 기준으로 추적 가능

## 한계

- 폼 블록 이름이 여러 종류면 종류별로 `TOCFORMSET`을 다시 설정해야 합니다.
- 표지처럼 다른 폼을 쓰는 항목은 수동 추가가 더 빠를 수 있습니다.
- 도면명 텍스트가 칸 밖에 있거나 여러 객체로 너무 흩어져 있으면 일부 수정이 필요할 수 있습니다.

## 권장 워크플로우

```text
TOCFORMSET
→ TOCFORMSCAN
→ 생성된 Table 확인
→ 누락/예외 항목만 수동 보정
```

